let cols, rows;
let cellSize = 20;
let grid; // Keeping grid for potential future use, but not strictly needed for current BFS/maze logic

let player;
let villain;

let gameEnded = false;
let gameWon = false;

let mazeCells = [];
let currentCell; // Used for maze generation
let stack = []; // Used for maze generation

let pathVillain = []; // Path for the villain's BFS
let villainMoveTimer = 0;
let villainMoveInterval = 500;

// Game State Variables (Patience, Skills, Obstacles)
let playerPatience;
let maxPatience = 1000; // Starting patience for the journey
let patienceDrainRate = 0.5; // How much patience drains per frame

let bureaucracyCost = 75; // Patience cost to pass a bureaucracy booth
let trafficJamDuration = 3000; // 3 seconds of traffic jam

let paralysisSkillCooldown = 10000; // 10 seconds cooldown (in ms)
let paralysisActiveDuration = 100; // 5 seconds paralysis (in ms)
let lastParalysisUseTime = -paralysisSkillCooldown; // Initialize so it's ready at start
let villainParalyzed = false;
let paralysisEndTime = 0;

// Coordinates for Farm (Start) and City (End)
let farmCellCoords = { i: 0, j: 0 }; // Top-left
let cityCellCoords = { i: 0, j: 0 }; // Bottom-right, calculated in setup

// --- CLASS DEFINITIONS ---

class MazeCell {
  constructor(i, j) {
    this.i = i;
    this.j = j;
    this.walls = {
      top: true,
      right: true,
      bottom: true,
      left: true
    };
    this.visited = false;
    this.difficultyType = null; // Can be 'bureaucracy' or 'traffic'
    this.trafficActive = false; // Is this traffic cell currently active?
    this.trafficStartTime = 0; // When did the traffic jam start?
  }

  show() {
    let x = this.i * cellSize;
    let y = this.j * cellSize;
    stroke(200);

    if (this.walls.top) line(x, y, x + cellSize, y);
    if (this.walls.right) line(x + cellSize, y, x + cellSize, y + cellSize);
    if (this.walls.bottom) line(x + cellSize, y + cellSize, x, y + cellSize);
    if (this.walls.left) line(x, y + cellSize, x, y);

    // Visuals for difficulty types
    if (this.difficultyType === 'bureaucracy') {
      fill(255, 150, 0, 150); // Orange transparent
      noStroke();
      rect(x, y, cellSize, cellSize);
      fill(255);
      textSize(cellSize * 0.5);
      textAlign(CENTER, CENTER);
      text('📋', x + cellSize / 2, y + cellSize / 2); // Clipboard icon
    } else if (this.difficultyType === 'traffic' && this.trafficActive) {
      fill(255, 0, 0, 100); // Red transparent
      noStroke();
      rect(x, y, cellSize, cellSize);
      fill(255);
      textSize(cellSize * 0.5);
      textAlign(CENTER, CENTER);
      text('🚦', x + cellSize / 2, y + cellSize / 2); // Traffic light icon
    }
  }

  checkNeighbors() {
    let neighbors = [];

    // Corrected neighbor indexing
    let top = this.index(this.i, this.j - 1);
    let right = this.index(this.i + 1, this.j);
    let bottom = this.index(this.i, this.j + 1);
    let left = this.index(this.i - 1, this.j);

    if (top && !top.visited) neighbors.push(top);
    if (right && !right.visited) neighbors.push(right);
    if (bottom && !bottom.visited) neighbors.push(bottom);
    if (left && !left.visited) neighbors.push(left);

    if (neighbors.length > 0) {
      let r = floor(random(neighbors.length));
      return neighbors[r];
    } else {
      return undefined;
    }
  }

  index(i, j) {
    if (i < 0 || j < 0 || i > cols - 1 || j > rows - 1) {
      return undefined;
    }
    return mazeCells[i + j * cols];
  }
}

class Player {
  constructor(startX, startY, charColor) {
    this.x = startX;
    this.y = startY;
    this.color = charColor;
    this.size = cellSize * 0.7;
    this.canMove = true; // Can be set to false during traffic jams
  }

  display() {
    noStroke();
    fill(this.color);
    ellipse(this.x * cellSize + cellSize / 2, this.y * cellSize + cellSize / 2, this.size, this.size);
  }
}

class Villain {
  constructor(startX, startY, charColor) {
    this.x = startX;
    this.y = startY;
    this.color = charColor;
    this.size = cellSize * 0.7;
  }

  display() {
    noStroke();
    fill(this.color);
    ellipse(this.x * cellSize + cellSize / 2, this.y * cellSize + cellSize / 2, this.size, this.size);
  }

  move() {
    if (pathVillain.length > 1) { // Ensure there's a path to follow
      let nextStep = pathVillain[1]; // Take the next step on the calculated path
      this.x = nextStep.x;
      this.y = nextStep.y;
    }
  }
}

// --- setup() FUNCTION ---
function setup() {
  createCanvas(600, 450);
  cols = floor(width / cellSize);
  rows = floor(height / cellSize);

  // Initialize game state (including player and villain)
  resetGame();
}

// --- draw() FUNCTION ---
function draw() {
  background(50); // Dark background for the maze

  // Draw maze cells
  for (let i = 0; i < mazeCells.length; i++) {
    mazeCells[i].show();
  }

  // Draw farm in the top-left corner (cell 0,0)
  drawFarm(farmCellCoords.i * cellSize, farmCellCoords.j * cellSize);

  // Draw city in the bottom-right corner (cell cols-1, rows-1)
  drawCity(cityCellCoords.i * cellSize, cityCellCoords.j * cellSize);

  if (!gameEnded) {
    // Update and display patience bar
    playerPatience -= patienceDrainRate;
    drawPatienceBar();

    // Update and display skill cooldown bar
    drawSkillCooldownBar();

    if (playerPatience <= 0) {
      gameEnded = true;
      gameWon = false;
    }

    // Check for active traffic jams
    player.canMove = true; // Reset player movement ability each frame
    for (let cell of mazeCells) {
      if (cell.difficultyType === 'traffic' && cell.trafficActive) {
        if (player.x === cell.i && player.y === cell.j) {
          player.canMove = false; // Player is stuck in traffic
          playerPatience -= patienceDrainRate * 3; // Faster patience drain in traffic
        }
        if (millis() - cell.trafficStartTime > trafficJamDuration) {
          cell.trafficActive = false; // Traffic jam ends
        }
      }
    }

    // Check if villain is paralyzed
    if (villainParalyzed) {
      if (millis() > paralysisEndTime) {
        villainParalyzed = false; // Paralysis wears off
      }
    }

    player.display();
    villain.display();

    // Villain only moves if not paralyzed
    if (!villainParalyzed && millis() - villainMoveTimer > villainMoveInterval) {
      villain.move();
      villainMoveTimer = millis();
    }

    // Recalculate villain path after player moves or villain moves
    // Villain avoids active traffic jams in its pathfinding
    pathVillain = findPathBFS(villain.x, villain.y, player.x, player.y);

    // Collision detection
    if (player.x === villain.x && player.y === villain.y) {
      gameEnded = true;
      gameWon = false;
    }

    // Win condition
    if (player.x === cityCellCoords.i && player.y === cityCellCoords.j) {
      gameEnded = true;
      gameWon = true;
    }
  } else {
    // Game Over / Win screen
    textAlign(CENTER, CENTER);
    textSize(50);
    if (gameWon) {
      fill(0, 255, 0);
      text("Você Ganhou! Bem-vindo à Cidade!", width / 2, height / 2);
    } else {
      fill(255, 0, 0);
      text("Game Over! Esgotado pela jornada...", width / 2, height / 2);
    }
    textSize(20);
    fill(255);
    text("Pressione 'R' para Reiniciar", width / 2, height / 2 + 50);
  }
}

// --- keyPressed() FUNCTION ---
function keyPressed() {
  if (!gameEnded && player.canMove) { // Only allow move if game not ended and player can move
    let nextX = player.x;
    let nextY = player.y;

    // Player movement
    if (keyCode === UP_ARROW) {
      nextY--;
    } else if (keyCode === DOWN_ARROW) {
      nextY++;
    } else if (keyCode === LEFT_ARROW) {
      nextX--;
    } else if (keyCode === RIGHT_ARROW) {
      nextX++;
    } else if (key === ' ' && !villainParalyzed) { // Spacebar for paralysis skill
      let currentTime = millis();
      if (currentTime - lastParalysisUseTime > paralysisSkillCooldown) {
        villainParalyzed = true;
        paralysisEndTime = currentTime + paralysisActiveDuration;
        lastParalysisUseTime = currentTime;
        console.log("Villain paralyzed!");
      } else {
        console.log("Paralysis skill on cooldown!");
      }
      return; // Prevent player from moving if spacebar is pressed
    }

    // Boundary check for next position
    if (nextX >= 0 && nextX < cols && nextY >= 0 && nextY < rows) {
      let currentMazeCell = mazeCells[player.x + player.y * cols];
      let nextMazeCell = mazeCells[nextX + nextY * cols];

      let canMove = false;
      // Check walls between current and next cell
      if (nextX > player.x && !currentMazeCell.walls.right) canMove = true;
      else if (nextX < player.x && !currentMazeCell.walls.left) canMove = true;
      else if (nextY > player.y && !currentMazeCell.walls.bottom) canMove = true;
      else if (nextY < player.y && !currentMazeCell.walls.top) canMove = true;

      if (canMove) {
        // Handle obstacles in the next cell
        if (nextMazeCell.difficultyType === 'bureaucracy') {
          if (playerPatience >= bureaucracyCost) {
            playerPatience -= bureaucracyCost;
            player.x = nextX;
            player.y = nextY;
            console.log("Passed bureaucracy! Patience -" + bureaucracyCost);
          } else {
            console.log("Not enough patience for bureaucracy!");
          }
        } else if (nextMazeCell.difficultyType === 'traffic' && nextMazeCell.trafficActive) {
          // Player cannot move into active traffic jam, but takes patience hit
          console.log("Traffic jam ahead! Cannot pass.");
          playerPatience -= patienceDrainRate * 5; // Extra drain
        } else if (nextMazeCell.difficultyType === 'traffic' && !nextMazeCell.trafficActive) {
            // Player enters inactive traffic cell, activates it
            nextMazeCell.trafficActive = true;
            nextMazeCell.trafficStartTime = millis();
            player.x = nextX;
            player.y = nextY;
            player.canMove = false; // Player is stuck immediately
            console.log("Entered a traffic jam!");
        }
        else {
          // Regular movement
          player.x = nextX;
          player.y = nextY;
        }
      }
    }
  } else if (key === 'r' || key === 'R') {
    resetGame();
  }
}

// --- removeWalls() FUNCTION (for maze generation) ---
function removeWalls(a, b) {
  let x = a.i - b.i;
  if (x === 1) { // 'a' is to the right of 'b'
    a.walls.left = false;
    b.walls.right = false;
  } else if (x === -1) { // 'a' is to the left of 'b'
    a.walls.right = false;
    b.walls.left = false;
  }

  let y = a.j - b.j;
  if (y === 1) { // 'a' is below 'b'
    a.walls.top = false;
    b.walls.bottom = false;
  } else if (y === -1) { // 'a' is above 'b'
    a.walls.bottom = false;
    b.walls.top = false;
  }
}

// --- findPathBFS() FUNCTION (for villain's pathfinding) ---
function findPathBFS(startX, startY, endX, endY) {
  let queue = [];
  let visited = create2DArray(cols, rows);
  let parent = create2DArray(cols, rows); // To reconstruct the path

  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      visited[i][j] = false;
      parent[i][j] = null;
    }
  }

  queue.push({ x: startX, y: startY });
  visited[startX][startY] = true;

  while (queue.length > 0) {
    let current = queue.shift();

    if (current.x === endX && current.y === endY) {
      // Path found, reconstruct it
      let path = [];
      let temp = current;
      while (temp !== null) {
        path.unshift(temp); // Add to the beginning to get correct order
        temp = parent[temp.x][temp.y];
      }
      return path;
    }

    let neighbors = [
      { dx: 0, dy: -1 }, // Top
      { dx: 0, dy: 1 }, // Bottom
      { dx: -1, dy: 0 }, // Left
      { dx: 1, dy: 0 } // Right
    ];

    for (let neighborOffset of neighbors) {
      let nx = current.x + neighborOffset.dx;
      let ny = current.y + neighborOffset.dy;

      // Check bounds
      if (nx >= 0 && nx < cols && ny >= 0 && ny < rows && !visited[nx][ny]) {
        let currentMazeCell = mazeCells[current.x + current.y * cols];
        let canMoveThroughWall = false;

        // Check if there's a wall between current and neighbor
        if (neighborOffset.dx === 1 && !currentMazeCell.walls.right) canMoveThroughWall = true;
        else if (neighborOffset.dx === -1 && !currentMazeCell.walls.left) canMoveThroughWall = true;
        else if (neighborOffset.dy === 1 && !currentMazeCell.walls.bottom) canMoveThroughWall = true;
        else if (neighborOffset.dy === -1 && !currentMazeCell.walls.top) canMoveThroughWall = true;

        // Villain avoids active traffic jams as obstacles
        let nextMazeCell = mazeCells[nx + ny * cols];
        if (nextMazeCell.difficultyType === 'traffic' && nextMazeCell.trafficActive) {
          canMoveThroughWall = false; // Villain considers active traffic cells impassable
        }

        if (canMoveThroughWall) {
          visited[nx][ny] = true;
          parent[nx][ny] = current;
          queue.push({ x: nx, y: ny });
        }
      }
    }
  }

  return []; // No path found
}


// --- create2DArray() FUNCTION ---
function create2DArray(cols, rows) {
  let arr = new Array(cols);
  for (let i = 0; i < cols; i++) {
    arr[i] = new Array(rows);
  }
  return arr;
}

// --- resetGame() FUNCTION ---
function resetGame() {
  gameEnded = false;
  gameWon = false;
  playerPatience = maxPatience; // Reset patience
  lastParalysisUseTime = -paralysisSkillCooldown; // Reset skill cooldown
  villainParalyzed = false; // Ensure villain is not paralyzed on reset

  // Set city coordinates (bottom-right cell)
  cityCellCoords.i = cols - 1;
  cityCellCoords.j = rows - 1;

  // Re-initialize mazeCells and regenerate the maze
  mazeCells = [];
  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) {
      let cell = new MazeCell(i, j);
      mazeCells.push(cell);
    }
  }
  currentCell = mazeCells[0]; // Start maze generation from top-left
  currentCell.visited = true;
  stack = [];
  stack.push(currentCell);

  while (stack.length > 0) {
    let next = currentCell.checkNeighbors();
    if (next) {
      next.visited = true;
      stack.push(currentCell);
      removeWalls(currentCell, next);
      currentCell = next;
    } else if (stack.length > 0) {
      currentCell = stack.pop();
    }
  }

  // Assign difficulty cells (avoiding start and end cells)
  let numBureaucracy = floor(mazeCells.length * 0.03); // 3% of cells
  let numTraffic = floor(mazeCells.length * 0.02); // 2% of cells

  // Helper to get a random, non-special cell
  function getRandomMazeCell() {
    let randCell;
    do {
      randCell = mazeCells[floor(random(mazeCells.length))];
    } while ((randCell.i === farmCellCoords.i && randCell.j === farmCellCoords.j) ||
             (randCell.i === cityCellCoords.i && randCell.j === cityCellCoords.j) ||
             randCell.difficultyType !== null); // Ensure it's not start/end/already difficulty
    return randCell;
  }

  for (let k = 0; k < numBureaucracy; k++) {
    let cell = getRandomMazeCell();
    cell.difficultyType = 'bureaucracy';
  }

  for (let k = 0; k < numTraffic; k++) {
    let cell = getRandomMazeCell();
    cell.difficultyType = 'traffic';
    // Optionally, some traffic jams could be active from the start
    if (random() < 0.2) { // 20% chance for an initial traffic jam
      cell.trafficActive = true;
      cell.trafficStartTime = millis();
    }
  }

  // Initialize player and villain positions
  player = new Player(farmCellCoords.i, farmCellCoords.j, color(0, 200, 0));
  villain = new Villain(cityCellCoords.i, cityCellCoords.j, color(200, 0, 0));

  // Initial villain path
  pathVillain = findPathBFS(villain.x, villain.y, player.x, player.y);
}

// --- Custom Drawing Functions ---

// Draws the player's patience bar
function drawPatienceBar() {
  let barWidth = map(playerPatience, 0, maxPatience, 0, width * 0.4);
  let barHeight = 20;
  let barX = width / 2 - (width * 0.4) / 2;
  let barY = 10;

  noStroke();
  fill(70); // Background of the bar
  rect(width / 2 - (width * 0.4) / 2, barY, width * 0.4, barHeight, 5); // Rounded corners

  fill(0, 200, 255); // Blue for patience
  rect(barX, barY, barWidth, barHeight, 5);

  fill(255);
  textSize(14);
  textAlign(CENTER, CENTER);
  text("Paciência", width / 2, barY + barHeight / 2);
}

// Draws the skill cooldown bar
function drawSkillCooldownBar() {
  let barWidth = width * 0.3;
  let barHeight = 15;
  let barX = width / 2 - barWidth / 2;
  let barY = 40; // Below patience bar

  let timeSinceLastUse = millis() - lastParalysisUseTime;
  let cooldownProgress = map(timeSinceLastUse, 0, paralysisSkillCooldown, 0, barWidth);
  cooldownProgress = constrain(cooldownProgress, 0, barWidth); // Clamp to bar width

  noStroke();
  fill(70); // Background of the bar
  rect(barX, barY, barWidth, barHeight, 5);

  if (timeSinceLastUse >= paralysisSkillCooldown) {
    fill(0, 255, 0); // Green when ready
  } else {
    fill(255, 100, 0); // Orange/red when on cooldown
  }
  rect(barX, barY, cooldownProgress, barHeight, 5);

  fill(255);
  textSize(12);
  textAlign(CENTER, CENTER);
  text("Paralisar (Espaço)", width / 2, barY + barHeight / 2);
}


function drawFarm(x, y) {
  push(); // Isolate drawing styles
  translate(x, y); // Move to the top-left corner of the cell

  // Ground
  fill(100, 200, 100); // Green
  noStroke();
  rect(0, 0, cellSize, cellSize); // Draw over one cell

  // Barn (simple red rectangle)
  fill(200, 50, 50); // Red
  rect(cellSize * 0.1, cellSize * 0.4, cellSize * 0.8, cellSize * 0.5);
  triangle(cellSize * 0.1, cellSize * 0.4, cellSize * 0.9, cellSize * 0.4, cellSize * 0.5, cellSize * 0.1);

  pop(); // Restore previous drawing styles
}

function drawCity(x, y) {
  push(); // Isolate drawing styles
  translate(x, y); // Move to the top-left corner of the cell

  // Gray city background
  fill(80, 90, 100);
  noStroke();
  rect(0, 0, cellSize, cellSize); // Draw over one cell

  // Buildings (simple rectangles)
  fill(120, 130, 140); // Building color
  rect(cellSize * 0.1, cellSize * 0.4, cellSize * 0.3, cellSize * 0.5);
  rect(cellSize * 0.5, cellSize * 0.2, cellSize * 0.4, cellSize * 0.7);

  // Windows (simple light blue squares)
  fill(150, 200, 255);
  rect(cellSize * 0.15, cellSize * 0.5, cellSize * 0.08, cellSize * 0.08);
  rect(cellSize * 0.55, cellSize * 0.3, cellSize * 0.08, cellSize * 0.08);

  pop(); // Restore previous drawing styles
}